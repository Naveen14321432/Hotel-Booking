const Footer = () => {
  return (
    <div className="bg-blue-300 py-10">
      <div className="container mx-auto flex justify-between items-center">
        <span className="text-3xl text-white font-bold tracking-tight">
          Hotelix.com
        </span>
        <div className="text-white font-bold tracking-tight flex items-center gap-4">
          <div>
            <br /><br />
            <p className="cursor-pointer">Contact Details</p>
            <p>Email: hotelix@gmail.com</p>
            <p>Phone: +91 8008657788</p>
          </div>
          <div className="flex gap-4">
            <p className="cursor-pointer">Privacy Policy</p>
            <p className="cursor-pointer">Terms of Service</p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Footer;
