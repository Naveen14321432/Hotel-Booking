export const hotelTypes = [
  "Budget",
  "Luxury",
  "Business",
  "Family",
  "Romantic",
  "Hiking Resort",
  "Cabin",
  "Beach Resort",
  "Golf Resort",
  "Motel",
  "All Inclusive",
  "Pet Friendly",
  "Self Catering",
];

export const hotelFacilities = [
  "Free WiFi",
  "Parking",
  "Family Rooms",
  "Non-Smoking Rooms",
  "Outdoor Pool",
  "Fitness Center",
];
